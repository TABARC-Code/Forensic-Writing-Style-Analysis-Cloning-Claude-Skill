# Style Report Template

Use this structure for all forensic style reports. Every section is mandatory for a full audit.
For quick clones, run the audit internally and skip to the Cloning Key.

---

## [AUTHOR NAME] — Forensic Style Report

**Corpus:** [List works or samples analysed]
**Confidence level:** [High / Solid / Partial / Seed]
**Corpus type:** [Known author from training knowledge / Unknown personal author — uploaded only]

---

### Master Voice Profile

[2–3 paragraph synthesis of the author's fundamental narrative posture. What is the emotional baseline? What does the prose believe about the world? What is the relationship between narrator, character, and reader? This is NOT theme — it is tone-of-voice.]

---

### Sentence Architecture

**Diagnosis:** [Describe the dominant sentence construction patterns]

**Mode parameters:**

| Mode | Word range | Dominant grammar |
|---|---|---|
| Action | [range] | [features] |
| Reflection | [range] | [features] |
| Observation | [range] | [features] |
| Climax | [range] | [features] |

**Core cadence unit:** [Name and describe — e.g. accumulate-then-strike, sustained crescendo, compound-and chain]

**Evidence:**
> [Short quote demonstrating the cadence unit]

**Cloning instruction:** [Specific, actionable instruction for reproducing this]

---

### Burstiness Profile

**Diagnosis:** [Strategic or ambient? How does it map to scene type?]

| Scene type | Burstiness | Character |
|---|---|---|
| Action | High / Med / Low | [description] |
| Dialogue | High / Med / Low | [description] |
| Reflection | High / Med / Low | [description] |
| Description | High / Med / Low | [description] |

**Cloning instruction:** [How to modulate sentence length by mode]

---

### Paragraph Cadence

**Diagnosis:** [Describe the paragraph-level rhythm]

**Chapter opening method:** [In medias res / establishing orientation / mid-thought / other]

**Paragraph pulse:** [Describe the four-stage pulse if present, or the actual pattern found]
- Entry:
- Expansion:
- Complication:
- Cut:

**Single-line paragraph use:** [Frequency, purpose, and context]

**Evidence:**
> [Quote showing the paragraph structure]

**Cloning instruction:** [How to structure paragraphs to match]

---

### Lexical Fingerprints

**Existential / conceptual vocabulary:**
[Word list — the conceptual skeleton of the prose]

**Qualifier tics:**

| Word | Function | Example |
|---|---|---|
| [word] | [what it signals] | [example] |

**Thematic clusters:**
[Name each cluster and list its vocabulary]

**Setting / domain jargon treatment:**
[Explained / Unexplained / Qualified-but-not-defined — with example]

**Cloning instruction:** [Vocabulary rules — what appears where, what is forbidden where]

---

### Contractions and Formality

**Narration register:** [Formal / Informal — contracted / uncontracted]
**Dialogue register:** [Formal / Informal — contracted / uncontracted]
**The gap:** [Describe the formality difference and its narrative purpose]

**Cloning instruction:** [How to maintain the correct register in each mode]

---

### Punctuation Personality

| Feature | Usage | Function |
|---|---|---|
| Em-dash | Frequent / Occasional / Rare | [purpose] |
| Ellipsis | Frequent / Occasional / Absent | [purpose] |
| Colon | Frequent / Occasional / Avoided | [purpose] |
| Semicolon | Present / Absent | [purpose] |
| Structural repetition | Present / Absent | [purpose and example] |

**Cloning instruction:** [Which punctuation tools to use, which to avoid]

---

### Perspective and Interiority

**Free indirect discourse:** [Present / Absent — describe depth and method]
**Self-observation pattern:** [Do characters watch themselves think? How often? How?]
**Temporal layering:** [Flashback / Intrusion / Neither — describe method and triggers]
**Tense slippage:** [Does interiority shift tense? Describe]

**Evidence:**
> [Quote showing FID or self-observation in action]

**Cloning instruction:** [How to handle POV, thought-tagging, and temporal movement]

---

### Dialogue Mechanics

**Subtext ratio:** [High / Medium / Low — describe how subtext is achieved]
**Attribution default:** [said / stripped / action beats]
**Response length pattern:** [Responses match / exceed / undercut preceding speech]
**Agreement-as-disagreement:** [Present / Absent — examples]
**Beat placement:** [Before / After / Instead of attribution]

**Evidence:**
> [Quote of a dialogue exchange showing these patterns]

**Cloning instruction:** [Full dialogue rules]

---

### Thematic Gravity

**Core preoccupations** (structural, not stated content):

1. [Theme] — [How it manifests in what gets noticed, what lingers, what goes unresolved]
2. [Theme] — [same]
3. [Theme] — [same]
4. [Theme if present]
5. [Theme if present]

**Cloning instruction:** [How to make structural choices consistent with these preoccupations]

---

## Style Signature

[100–150 word paragraph. Captures the author's essential voice in a way that would allow someone unfamiliar with their work to understand it immediately. Include one memorable simile or analogy. End with a statement of what makes this voice distinct from its genre peers.]

---

## Cloning Key — 7 Rules

1. [Most important — usually the narration/dialogue gap or the sentence rhythm]
2.
3.
4.
5.
6.
7.

---

## The Forbidden List

These patterns must be actively avoided — they break the voice:

- [Pattern to avoid]
- [Pattern to avoid]
- [Pattern to avoid]
- [At least 5 total]
