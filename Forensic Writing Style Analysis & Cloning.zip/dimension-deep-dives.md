# Dimension Deep Dives

Extended guidance for analysing each of the 10 forensic dimensions.
Read the relevant section when the SKILL.md guidance is insufficient.

---

## Dimension 1: Master Voice Profile — Extended

The hardest dimension to articulate and the most important to get right.
It is the lens through which all other dimensions are read.

**Finding the emotional register:**
Read 500 words of introspective narration — not action, not dialogue.
Ask: what does the prose sound like if you remove all plot?
What feeling lingers when the events are stripped away?
That residue is the register.

**Common registers and their prose signatures:**

- **Elegiac gravity** — formal sentence structure, temporal qualifiers (still / already / once), philosophical vocabulary, things continuing past their rightful end
- **Sardonic detachment** — observational distance, ironic modifiers, understatement as truth-telling, deadpan delivery of difficult content
- **Breathless momentum** — action-dominant syntax, accumulating clauses without resolution, present tense or present-tense feeling in past tense
- **Clinical precision** — absence of emotional vocabulary, observation as action, consequences described without affect
- **Warm irony** — close third or first person with comic distance, self-deprecating interiority, affection for foolish characters
- **Prophetic weight** — declarative sentences as universal truth, second-person address, the narrator as witness to something significant

**The narrator-character relationship:**
Is the narrator identical with the character (no distance) or slightly above them (mild omniscience)?
Does the narrator know more than the character, or only what the character knows?
This shapes every perspective decision in the clone.

**What the prose believes:**
Extract 3–5 implicit beliefs from the text. Examples:
- "The world continues indifferently while the individual suffers"
- "People act for reasons they cannot articulate even to themselves"
- "Physical objects carry moral weight"
- "Institutions exist to fail the people inside them"

---

## Dimension 2: Sentence Architecture — Extended

### Finding mode-specific ranges

To calibrate sentence length by mode, find 10 clear examples of each mode and count words.
Use the average and range to set parameters.

### The Accumulate-Then-Strike pattern

Identify it by:
1. Finding paragraphs where the last sentence is dramatically shorter than the rest
2. Checking if the short sentence either names something directly, pivots emotionally, or ends with a word of high thematic weight
3. Measuring frequency — if it appears more than once every three paragraphs, it is a signature pattern

### Participial stacking — how to measure

Count sentences where description, atmosphere, or secondary action is carried inside the grammar of a primary action sentence (via participials, absolutes, or appositives). Compare to sentences where these elements are in separate sentences.

High ratio = participial stacker.
Low ratio = block-describer.

**Stacked example:**
"She crossed the room, her heels loud on the stone, the rain beyond the windows turning the courtyard silver."

**Block example:**
"She crossed the room. Her heels were loud on the stone. Rain turned the courtyard silver."

Different rhythm, different feel. Know which you are reproducing.

### The fragment spectrum

- **Intentional fragments** — appear at structurally significant moments, often alone in a paragraph or at the end of a sequence
- **Accumulated fragments** — appear in action sequences as a deliberate staccato effect
- **Absent fragments** — the author always completes their sentences

---

## Dimension 3: Burstiness — Extended

Burstiness is not the same as variety. An author can have low burstiness across the whole text but high burstiness within action sequences.

**Measuring burstiness:**
For each major scene type, calculate:
- Average sentence length (words)
- Standard deviation of sentence lengths
- Range (shortest to longest)

High SD + wide range = high burstiness
Low SD + narrow range = low burstiness

**Strategic vs. random burstiness:**

*Strategic:* High in action/revelation. Low in reflection/description.
Intentional control — the author uses variation to signal intensity.

*Ambient:* Similar burstiness across all scene types, or unpredictable variation unrelated to scene type.
Still cloneable — just requires a different instruction.

---

## Dimension 4: Paragraph Cadence — Extended

### The four-stage pulse in detail

Test for it before assuming it. To identify:
1. Find 20 consecutive paragraphs (not dialogue)
2. Is the first sentence short and declarative?
3. Is the last sentence shorter than the sentences before it?
4. Is there a complicating sentence in the middle?

If >60% of paragraphs show this pattern, it is a defining feature.

### Chapter opening taxonomy

**In medias res (Type 1):** Character in motion, no orientation. Reader confused for 1–3 paragraphs. Setting arrives through action.

**In medias res (Type 2):** Character in a state (emotional, physical), no orientation. Character described before location.

**In medias res (Type 3):** Dialogue before any description. First line is spoken, often without context.

**Establishing-first:** Setting arrives before character. Used by authors who view landscape as thematically primary.

**Epigraph-bridged:** A quotation or abstract statement precedes the chapter. The opening prose responds to or contradicts it.

### Paragraph length variance

Average paragraph length and its variance tells you the author's unit of thought.
High variance (some paragraphs 1 sentence, some 10+) = structurally expressive.
Low variance = consistent, less modulated.

---

## Dimension 5: Lexical Fingerprints — Extended

### Building the existential vocabulary list

Go through 3,000+ words of narration (not dialogue) and highlight every abstract noun that is not domain-specific jargon. Abstract nouns appearing more than 3 times are likely intentional. Those appearing across different scene types are core vocabulary.

### Qualifier tic analysis

Build a frequency list of:
- Temporal qualifiers: still, already, once, now, then, before, after
- Modal qualifiers: perhaps, surely, possibly, certainly, no doubt
- Minimising qualifiers: merely, only, just, hardly, barely
- Maximising qualifiers: utterly, absolutely, entirely, completely

An author with a distinct qualifier profile is very clonable. These small words create recognisable rhythmic texture that is hard to replicate without explicitly targeting them.

### Thematic cluster mapping

A thematic cluster is a group of words that appear together in a specific narrative register. To identify:
1. Find 5 scenes of the same type (5 action scenes, 5 introspective scenes)
2. List all content words from each group
3. Find words appearing in multiple scenes of the same type but rarely in others

These are your clusters.

---

## Dimension 6: Contractions and Formality — Extended

**The narration-dialogue gap:**
This is one of the most reliable and clonable voice fingerprints.

Test it by taking one sentence of narration and one line of dialogue from the same scene.
Would the narrator's sentence work as dialogue? Would the dialogue work as narration?
If yes to either, the gap is small. If no to both, the gap is large and deliberate.

**Formality under pressure:**
Some authors become MORE formal when writing about intense emotion — the prose locks up, becomes controlled. Others LESS formal — they fragment, rush, drop structure.
Find three emotionally intense passages and measure formality relative to the author's baseline.

---

## Dimension 8: Perspective and Interiority — Extended

### Testing for free indirect discourse

FID is present when:
- Character thoughts appear in narration without "he thought" or "she wondered"
- The narrator's vocabulary adopts the character's vocabulary or idiom
- Rhetorical questions appear in narration (these are the character thinking, not the narrator asking)
- Present tense appears in otherwise past-tense narration within interiority passages

Test: Find an interior passage. If you can add "he thought" or "she realised" at the start of any sentence without changing meaning, FID is at work.

### Self-observation technique

Characters with meta-cognition — watching their own thought processes from a slight distance. This creates interior irony that prevents sentimentality and gives distressed characters a quality of controlled dignity.

Identify by finding:
- Short corrective sentences after strong feeling ("That was foolish.")
- Rhetorical questions the character immediately answers ("Was it grief? Perhaps.")
- Observations about the character's own patterns ("She had done it again.")

This technique is author-specific. Do not add it to a clone if the corpus does not show it.

---

## Dimension 9: Dialogue Mechanics — Extended

### Measuring subtext ratio

Take 10 dialogue exchanges. For each, identify:
- The stated content (what is literally said)
- The implied content (what is actually meant)
- The gap (how much is left unsaid vs. stated)

If stated ≠ implied in more than 60% of exchanges, this is a high-subtext author.

### Agreement-as-disagreement

Identify it by finding exchanges where:
- Character A makes a statement or request
- Character B responds affirmatively
- But the affirmative contains a qualification, reversal, or reframing that contradicts the spirit of the agreement

The disagreement is inside the grammar of apparent agreement.

### Beat placement taxonomy

**Beat-before:** Action beat precedes the speech. Establishes character state before words.
"She put down her cup. 'I won't be coming.'"

**Beat-after:** Action beat follows the speech. Shows response or continuation.
"'I won't be coming.' She picked up her coat and moved towards the door."

**Beat-instead:** No attribution verb. The action IS the attribution.
"'I won't be coming.' He looked away."

**Embedded beat:** Mid-speech action beat that breaks the dialogue line.
"'I won't'—she paused, seemed to reconsider—'be coming after all.'"

Map which pattern the author defaults to and how they vary it.
