# Sampling Protocol for Text Analysis

How to extract the right material from uploaded texts for style analysis.

---

## File Type Routing

Before sampling, ensure the text is accessible:

- **.txt files** — read directly; use `wc -c` to check size, then `head`, `tail`, and `sed` for mid-sections
- **.pdf files** — link to `pdf-reading` skill before analysis
- **.docx files** — link to `file-reading` skill to route to pandoc extraction
- **.epub files** — `pandoc file.epub -t plain | head -n 200`

---

## Sampling by File Size

### Under 50KB (~25,000 words)
Read the full text. No sampling needed. Small corpus — note confidence limits.

### 50–200KB (~25,000–100,000 words)
Sample three zones:
1. **Opening zone:** Lines 1–300
2. **Mid zone:** Lines at 40–50% of total line count
3. **Late zone:** Lines at 75–85% of total

```bash
wc -l file.txt                          # get total line count
head -300 file.txt                      # opening zone
sed -n 'START,ENDp' file.txt            # mid zone (calculate from total)
tail -300 file.txt | head -200          # late zone
```

### 200KB–1MB (novel length)
Sample five zones:
1. Opening: first 250 lines
2. Early-mid: lines at 20% of total
3. Mid: lines at 50% of total
4. Late-mid: lines at 75% of total
5. End: last 200 lines

Extract 60–80 lines per zone (~350 lines total).

### Over 1MB (multiple books or very long works)
Sample across works:
- For each work: opening 150 lines + one middle section of 150 lines
- If a single very long file: sample at 10%, 30%, 50%, 70%, 90% of line count

---

## What to Look For in Each Zone

### Opening zone
- Chapter-opening method (in medias res? establishing orientation?)
- Default sentence length and register
- First dialogue exchange
- How setting / world is introduced

### Middle zones
- Action sequences
- Dialogue-heavy scenes
- Introspective passages
- Mode transitions

### Late zone
- Emotional climax handling
- Single-line paragraph usage
- Whether resolution is achieved or left open
- Final register — does it match the opening or shift?

---

## Identifying Scene Type Boundaries

**Action sequence start:** Short declarative sentence after a break. Physical verbs dominant.
**Action sequence end:** Single short line, often thematically weighted.

**Dialogue scene start:** Opening speech or action beat before first speech.
**Dialogue scene end:** Beat of silence, character departure, or narrator summary.

**Introspective passage start:** Character pauses or observes something. Long sentence follows.
**Introspective passage end:** Short sentence of resolution or return to action.

---

## Building the Comparison Matrix

For each sampled passage, note:
1. Scene type
2. Average sentence length (estimate)
3. Presence of participial stacking (yes / no)
4. Presence of FID (yes / no)
5. Any distinctive vocabulary
6. Any rule-breaking (fragments, tense shifts, unusual punctuation)

This matrix becomes the evidence base for the forensic report.

---

## Multi-Work Corpus Strategy

When analysing multiple works by the same author:

**Consistency audit:** Which patterns appear in all works? (Core voice — clone this)
**Development audit:** Which patterns change across works? (Author evolution — note the version you are targeting)
**Genre-specific patterns:** Which patterns appear only in one context? (Apply only when writing in that context)
