# Multi-Generation Improvement Tracker

Use this template to track how voice-clone rules evolve across improvement cycles.
The goal: each generation produces fewer identifiable breaks than the last.

---

## Project Details

**Author:** [Name or pseudonym]
**Project:** [What is being written]
**Corpus size:** [Word count and number of works]
**Corpus type:** [Known from training / Uploaded only]
**Session started:** [Date or session label]

---

## Baseline Rules (Generation 0)

*Derived from initial forensic audit. Unrefined.*

**Core rhythm:** [e.g. accumulate-then-strike, sustained crescendo]
**Sentence mode rules:** [action / reflection / observation / climax parameters]
**Vocabulary restrictions:** [what goes where, what is forbidden where]
**Dialogue rules:** [subtext method, attribution style, response length]
**Perspective rules:** [FID depth, self-observation, tense handling]
**Register:** [narration register / dialogue register / the gap]

---

## Generation 1

### What was generated:
[Brief description — scene type, length, content]

### Feedback / evaluation:
**Passages that worked:**
- [Quote or description]

**Passages that broke:**
- [Quote or description — and why it felt wrong]

### Drift diagnosis:

| Break | Dimension | Root cause | Fix |
|---|---|---|---|
| [description] | [Dim #] | [cause] | [correction] |

### OLD / NEW rule pairs:

| OLD | NEW |
|---|---|
| [previous rule] | [updated rule] |

### Refined rules carried into Generation 2:
*Only list rules that changed. All unchanged rules carry forward.*
- [Changed rule]
- [New rule derived from analysis]

---

## Generation 2

### What was generated:
[Brief description]

### Feedback / evaluation:
**Passages that worked:**

**Passages that broke:**

### Drift diagnosis:

| Break | Dimension | Root cause | Fix |
|---|---|---|---|

### OLD / NEW rule pairs:

| OLD | NEW |
|---|---|

### Refined rules for Generation 3:

---

## Generation 3

[Continue pattern as needed]

---

## Final Rule Set

*Document when improvement plateaus or user is satisfied.*
*This is the authoritative cloning instruction set for [Author Name].*

### Sentence rules:
1.
2.
3.

### Vocabulary rules:
1.
2.

### Perspective rules:
1.
2.

### Dialogue rules:
1.
2.

### Forbidden patterns:
1.
2.
3.

---

## Improvement Metrics

| Generation | Breaks identified | Breaks per 500 words | Notes |
|---|---|---|---|
| 0 (baseline) | — | — | Initial audit |
| 1 | | | |
| 2 | | | |
| Final | | | |

**Target:** fewer than 1 break per 500 words, user satisfied with register and voice.
