# Activation Prompts for Voice Clone Generation

Tested prompt structures that reliably produce accurate voice-clone output.
Use these as templates when generating content in a cloned voice.

---

## Scene Type Prompts

### Action / Combat Scene

```
Write a [duration/scale] action scene in [Author]'s voice.

Setting: [location and its historical/physical condition]
POV character: [name, relevant physical or emotional state]
The action: [what happens — specific, not general]

Apply these rules:
- Sentences in action mode: 6–18 words, dominant verbs
- Restrict to POV character's sensory range only — no omniscient view
- Atmosphere woven into the grammar of action via participial phrases
- Specific body parts, specific objects, named consequences — never "chaos erupted"
- POV character interiority appears briefly between action beats, untagged
- Physical capability carries a visible cost — note it once
```

### Introspective / Reflection Scene

```
Write an introspective passage in [Author]'s voice.

Character: [name, what they are reflecting on]
Trigger: [what prompted the reflection — object, decision, sensation]
The reflection concerns: [theme or situation]

Apply these rules:
- Sentences in reflection mode: 20–50 words, clause-heavy
- Free indirect discourse — thoughts appear in narration untagged
- Character observes themselves thinking at least twice
- Include one temporal intrusion (1–3 sentences max) triggered by a sensory prompt
- End with a crystallisation: a very short sentence or single-line paragraph
  at the moment the character reaches a conclusion
- The conclusion should be a decision to act, not an expression of hope
```

### Dialogue Scene

```
Write a dialogue scene in [Author]'s voice between [Character A] and [Character B].

What Character A wants: [goal]
What Character B wants: [goal]
Why they disagree: [the tension]
What neither will say directly: [the real subject]

Apply these rules:
- Neither character states the real subject directly
- Use agreement to signal disagreement at least once
- Responses shorter than the speeches that prompt them
- Attribution: default to "said"; use action beats instead where possible
- No adverb-modified attribution (no "he said coldly")
- The most important information is in the shortest line
- End on what is NOT said — leave the real tension hanging
```

### Chapter Opening

```
Write a chapter opening in [Author]'s voice.

Scene: [what is happening]
POV character: [name, state]
What has just happened (the aftermath being entered): [context]

Apply these rules:
- Begin 3 beats INTO the scene — no orientation
- Do not establish who, where, or why before beginning
- Character in motion or in a state before the setting is named
- Setting arrives through the gaps in the action
- First sentence should be short and declarative, or a fragment
- Clarity comes through momentum, not preamble
```

### Environmental / World-Building Passage

```
Write a description of [location] in [Author]'s voice.

Historical condition of this place: [what has happened here]
Current state: [what it looks like now]
Who is observing it: [POV character]
What their presence here means: [thematic or plot significance]

Apply these rules:
- Describe in terms of condition and history, not atmosphere or feeling
- Do not mirror the character's emotional state in the environment
- Domain terminology: qualify by physical description only, never explain
- One detail that is incongruous or out of place
- Buildings and spaces reflect what has happened in them, not what is felt
```

---

## Character and Voice Tests

Use these to stress-test whether the clone is holding under different demands.

### Philosophical test
```
Write a passage in which [Author's character] considers [abstract concept].
They should reach a conclusion — but the conclusion must be structural
(a decision to act) rather than emotional (a feeling of resolution).
```

### Dialogue subtext test
```
Write a scene in which [Character A] asks [Character B] for help.
Character B refuses without ever saying no.
```

### Physical register test
```
Write a description of [character] in a moment of physical effort or pain.
The body should function as a moral register — what this person's physical
state reveals about their interior condition.
```

### Multi-mode test
```
Write a 400-word scene that moves through all four sentence modes:
start in observation, move to action, shift to interiority, end in revelation.
Transitions between modes should be abrupt — no bridging sentences.
```

### Micro-format test (tweets, headlines, posts)
```
Write [N] posts in [Author/Account]'s voice about [topic].
Match: sentence length distribution, structural patterns, vocabulary density.
No elaboration beyond what appears in the source samples.
Length check before delivery.
```

---

## Activating Phrases — What Triggers This Skill

**Analysis requests:**
- "Analyse this writing style"
- "What makes this author distinctive?"
- "Break down how this is written"
- "What's the voice here?"
- "Reverse-engineer this prose"
- "Give me a style audit of [author/text]"

**Clone requests:**
- "Write in the style of [author]"
- "Sound like [author]"
- "Continue this in the same voice"
- "Ghost-write this for me in [person's] style"
- "Match this tone"
- "Write like this but about [topic]"

**Authenticity requests:**
- "Does this sound like [author]?"
- "What's off about this passage?"
- "Audit this for voice consistency"
- "Would this pass as [author]'s work?"
- "Find where this breaks from [author]'s style"

**Implicit triggers (paste-and-ask):**
- User pastes text + asks for more or a continuation
- User pastes text + asks "what do you notice?"
- User mentions they are ghostwriting for someone
- User asks Claude to "match the tone" of anything
- User pastes text + asks if it sounds like a specific person
