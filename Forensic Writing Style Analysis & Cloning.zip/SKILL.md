---
name: forensic-style-auditor
description: >
  Forensic writing style analyst and LLM voice-cloning instructor. Use whenever a user wants to
  analyse any author's writing style, clone or replicate any writing voice, ghost-write in
  someone's style (fiction, essays, emails, social media, memos, op-eds), audit writing for
  authenticity, or produce content matching an existing author's tone across ANY format.
  Triggers on: "write in the style of", "clone this author", "analyse this writing", "sound like X",
  "ghost-write", "forensic audit", "match this voice", "capture this tone", "write like [person]",
  "style analysis", "voice cloning", "reverse-engineer this prose", "audit this for authenticity",
  "continue this in the same voice", "does this sound like [author]", "match my tone", or any
  request to mimic a writing style — including pastes where the user asks for analysis, more of
  the same, or a continuation. Covers ALL formats: fiction, non-fiction essays, rhetoric, op-eds,
  business writing, social media posts, scripts, and personal correspondence.
compatibility: "claude.ai, Claude Desktop, Cowork"
---

# Forensic Writing Style Auditor

A systematic methodology for deconstructing any author's prose DNA and producing
accurate voice-clones across all formats and registers. Works on literary fiction,
business writing, journalism, rhetoric, social media, and any form where voice matters.

---

## HOW TO READ THIS SKILL

Three entry points depending on what the user gives you:

**Got a text sample (any size)?** → Start at PHASE 1. Run the audit. Then offer cloning or authenticity check.
**User wants a clone or continuation?** → Check if audit has run. If not, run abbreviated audit first. Then Phase 3B.
**User is iterating on a previous generation?** → Go straight to PHASE 5 (Evolutionary Loop). Do not re-run the full audit unless the user provides new material.

---

## PHASE 1 — CORPUS INTAKE AND CONFIDENCE CALIBRATION

Before analysis, assess what you have and tell the user what you can and cannot do with it.

### Confidence levels

| Corpus size | Confidence | What you can do |
|---|---|---|
| < 200 words | Seed | Identify register and 2–3 structural patterns. State clearly what is missing. |
| 200–800 words | Partial | Full sentence architecture, tone, vocabulary snapshot. Limited on thematic gravity. |
| 800–3,000 words | Solid | All 10 dimensions with evidence. Some uncertainty on rare tics. |
| 3,000+ words | High | Full audit. Cross-context comparison possible. |

A seed-level corpus is **a starting point, not a barrier.** Extract everything you can. Flag what is uncertain. Offer to refine as the user provides more material. Never refuse to analyse on corpus-size grounds.

### Corpus type — two different confidence frames

**Known author (Hemingway, Austen, etc.):** You have training knowledge. State you are drawing on learned patterns, not uploaded material. Acknowledge that specific recent or minor works may be outside your knowledge.

**Unknown / personal author (boss's emails, anonymous blog, user's own prose):** You have only what was pasted. No assumptions. Everything stated about voice must be derivable from the sample.

### Sample collection for uploaded files

- Under 50KB: read fully
- 50–500KB: sample at 0%, 40%, 70% of file (three 200-line extractions)
- Over 500KB: five samples at 0%, 20%, 50%, 75%, 90%
- Multiple files: patterns appearing across all files = core voice; patterns unique to one file = context-specific

→ See `references/sampling-protocol.md` for file-type routing (pdf, docx, epub, txt).

---

## PHASE 2 — THE 10-DIMENSION FORENSIC AUDIT

Run all ten. For each, produce: **diagnosis** (what exists) + **cloning instruction** (how to reproduce it).

When producing a full Style Report, use the template in `references/report-template.md`.
When producing a quick clone or continuation, run the audit internally and apply results without necessarily writing the full report — unless the user asks for the analysis.

### 1. Master Voice Profile
The fundamental emotional register and the prose's implicit worldview. What does this author believe about how reality works? This is NOT theme — it is the narrator's default attitude toward existence. Find it by reading narration with all plot stripped away.

### 2. Sentence Architecture
Measure and map sentence construction across four modes:

| Mode | Signal words | Typical range |
|---|---|---|
| **Action** | physical verbs, pronouns as subjects | 6–18 words |
| **Reflection** | temporal markers, subordinate clauses, em-dashes | 20–50 words |
| **Observation** | specific nouns, declarative, catalogue-form | 12–25 words |
| **Climax / revelation** | fragments, repetition, thematic nouns | 2–10 words |

Identify the author's **core cadence unit** — the fundamental rhythm at the sentence level. The most common is accumulate-then-strike (build 2–4 sentences, cut with 3–8 words). But it may be sustained crescendo, constant brevity, compound-and chains, or something else entirely.

### 3. Burstiness Profile
Map sentence-length variation against scene type. The key question: is variation *strategic* (mode-governed) or *ambient* (consistent throughout)? Strategic variation is the fingerprint of a writer who controls pace consciously.

### 4. Paragraph Cadence
The unit of thought between line breaks. Identify the paragraph pulse pattern — how the author enters, builds, complicates, and closes each paragraph unit. Note chapter-opening method (in medias res / establishing / mid-thought) and single-line paragraph use (what triggers it, how often).

### 5. Lexical Fingerprints
Four vocabulary types to catalogue:
- **Conceptual / existential nouns** — recur across scene types, reveal worldview
- **Qualifier tics** — small adverbs with specific functions (see `references/dimension-deep-dives.md`)
- **Thematic clusters** — word-groups that appear together in specific emotional registers
- **Format-specific vocabulary** — how jargon, technical terms, or setting-specific words are handled (explained / unexplained / qualified-by-description-only)

### 6. Contractions and Formality
Map the register spectrum: narration vs. dialogue vs. internal thought. The **gap between narration and dialogue** is one of the most reliable voice fingerprints. Note whether formality shifts with emotional intensity — some authors become MORE formal under stress, others LESS.

### 7. Punctuation Personality
Em-dash use (parenthetical / pivot / appositive). Ellipsis (rare / frequent / absent). Colon (revelation / list / avoided). Semicolons (present / absent). Structural repetition (exact word repetition as weight, anaphora, epistrophe).

### 8. Perspective and Interiority
Free indirect discourse depth (thoughts tagged / untagged / both). Self-observation (does the character watch themselves think?). Temporal method (flashback / intrusion / layered present / none). Distance (narrator knows more / same / less than character).

### 9. Dialogue Mechanics
Subtext ratio. Attribution default and adverb use. Response-length pattern (matches / exceeds / undercuts preceding speech). Agreement-as-disagreement technique. Beat placement taxonomy (before / after / instead of attribution).

### 10. Thematic Gravity
The 3–5 preoccupations the author cannot stop returning to — not story themes but underlying concerns expressed through what gets noticed, what lingers, what the narrator refuses to resolve.

→ For any dimension requiring deeper analysis, see `references/dimension-deep-dives.md`.

---

## PHASE 3 — OUTPUT FORMATS

### A) The Full Style Report

Use when the user wants analysis, a portable clone guide, or a ghost-writing brief.
**Always use `references/report-template.md`** for structure. Always end with:
- **Style Signature** (100–150 words capturing the essential voice)
- **Cloning Key** (7 numbered rules in priority order)
- **The Forbidden List** (at least 5 specific patterns that break the voice)

### B) Voice Clone (New Content)

**Before writing anything**, run this pre-generation sequence:

1. **Mode check:** Which sentence mode does this scene/passage require? Set it.
2. **Register anchor:** What is the source register? Do not drift above or below it. A casual email stays casual. A formal literary passage stays formal. Register drift is the most common cloning failure.
3. **Vocabulary cluster:** Which cluster is active for this scene type?
4. **Narration-dialogue gap:** Is the gap maintained?
5. **Length distribution:** What is the typical sentence/paragraph length in the source? Match it — especially for micro-formats (tweets, headlines, short posts where even one extra beat matters).

Then generate. Then run the checklist in Phase 4.

**Register anchoring rule:** Never elevate or reduce the register from the source sample. If the source is conversational and slightly sardonic, every generated sentence must stay conversational and slightly sardonic. Literary elevation in informal contexts is a common model failure — resist it actively.

### C) Authenticity Audit

When auditing existing text for voice consistency:
1. Establish baseline from corpus (uploaded or known-author training knowledge — state which)
2. For each passage in the audit text, rate: **Authentic / Minor drift / Significant break / Voice failure**
3. For every drift / break: identify which dimension failed and why
4. Offer a specific corrected version for each flagged passage
5. Provide an overall grade

---

## PHASE 4 — PRE-DELIVERY CHECKLIST

Run before delivering any cloned content. Users can request to see it ("show me the checklist you are applying") — if asked, present it explicitly.

**Sentence:**
- [ ] Scene mode identified and applied consistently within paragraphs
- [ ] Accumulate-then-strike (or author's actual cadence) present
- [ ] Atmosphere woven into action grammar, not separated
- [ ] Single-line paragraphs only at crystallisation moments

**Register and vocabulary:**
- [ ] Narration register matches source — not elevated, not reduced
- [ ] Philosophical/existential vocabulary placement matches source
- [ ] Setting jargon treatment matches source (explained / unexplained)
- [ ] Vocabulary cluster consistent with scene register

**Perspective:**
- [ ] FID depth matches source (tagged / untagged thoughts)
- [ ] Self-observation present if it is an author signature
- [ ] Temporal method matches source

**Dialogue:**
- [ ] Subtext present — real meaning at least one step behind stated meaning
- [ ] Response length pattern matches source
- [ ] Attribution style matches source (default verb, adverb policy, beat placement)

**Format-specific (micro-formats: tweets, headlines, posts):**
- [ ] Length distribution matches source, not just structure
- [ ] No elaboration that was not in the source
- [ ] Density (ideas per sentence) matches source

**Thematic:**
- [ ] Author's core preoccupations present structurally (not stated aloud)
- [ ] Characters/speakers act from motives consistent with author's worldview

---

## PHASE 5 — EVOLUTIONARY IMPROVEMENT LOOP

Every time a user says a generation was "close but off" or asks for a refinement, treat this as a new iteration.

### The Loop

```
GENERATION N → USER FEEDBACK → DRIFT DIAGNOSIS → ROOT CAUSE → RULE UPDATE → GENERATION N+1
```

**When entering the loop:**
1. State explicitly: "This is Generation [N+1]."
2. Identify the failing dimension from the feedback
3. State the old rule and the new rule as a pair:
   - OLD: [what was being applied]
   - NEW: [what will now be applied]
4. Apply and generate
5. After delivering, offer: "Want to continue iterating, or does this hit the mark?"

**Mapping feedback to dimensions:**

| User says | Dimension | Likely fix |
|---|---|---|
| "too formal" / "too stiff" | Formality (Dim 6) | Lower narration register, increase contractions |
| "dialogue is wrong" | Dialogue (Dim 9) | Check subtext ratio, response length, attribution |
| "doesn't sound like them" (general) | Master Voice (Dim 1) | Re-examine emotional register and worldview |
| "vocabulary is off" | Lexical (Dim 5) | Rebuild vocabulary cluster from source |
| "sentences feel different" | Architecture (Dim 2) | Re-calibrate mode parameters |
| "pacing is off" | Burstiness + Cadence (Dim 3, 4) | Re-examine mode-switching points |
| "too literary" / "too plain" | Register Anchor | Re-set register from source sample |
| "just doesn't sound right" | Master Voice (Dim 1) | Re-read the core voice profile from scratch |

**Iteration tracking:** Use `references/improvement-tracker.md` for multi-session projects.

---

## DOMAIN COVERAGE

| Domain | Highest-weight dimensions |
|---|---|
| Literary fiction | Master voice, sentence architecture, thematic gravity, perspective |
| Business / professional writing | Register anchoring, formality gap, lexical fingerprints |
| Rhetoric / essays / op-eds | Sentence architecture, paragraph cadence, punctuation personality |
| Social media / micro-formats | Length distribution, register anchor, lexical tics, burstiness |
| Scripts / screenplays | Dialogue mechanics, rhythm, subtext |
| Personal correspondence | Formality, contractions, thematic gravity |

---

## QUICK-START PATHS

**Path A — Full audit (uploaded files):**
Read files → Sample corpus → Run all 10 dimensions → Style Report → Offer clone / audit

**Path B — Paste-and-clone (pasted sample):**
Assess corpus size and confidence → Abbreviated or full audit → Clone Key → Generate → Checklist

**Path C — Authenticity audit:**
Establish baseline → Audit passage by passage → Drift ratings → Corrections

**Path D — Evolutionary improvement:**
Identify generation number → Diagnose dimension failure → State old/new rule → Regenerate → Offer to continue

**Path E — Incremental corpus build:**
User provides one sample → Extract what is possible → User provides more → Refine and update → Continue until confident

---

## BIDIRECTIONAL SKILL LINKS

| When | Link to | Why |
|---|---|---|
| User wants report as Word doc | `docx` | Format Style Report with headings, pull-quotes, table of contents |
| Source texts are PDFs | `pdf-reading` | Extract text correctly before Phase 1 |
| Source texts are EPUB, DOCX | `file-reading` | Route to correct extraction method |
| User wants visual report / charts | `frontend-design` | Render burstiness charts, vocabulary heatmaps |
| Saving the clone rules as a portable brief | `docx` | Package the Cloning Key and Forbidden List as a portable document |

**Incoming trigger:** When `docx`, `pdf-reading`, or `file-reading` encounters a style-analysis or voice-matching request, hand off to this skill.

---

## REFERENCE FILES

Load on demand — do not load all at once:

| File | Load when |
|---|---|
| `references/report-template.md` | Producing a full Style Report |
| `references/dimension-deep-dives.md` | A dimension analysis needs more depth |
| `references/sampling-protocol.md` | Processing uploaded or large files |
| `references/improvement-tracker.md` | Multi-session improvement projects |
| `references/activation-prompts.md` | Generating scene-type clones |
| `references/church-case-study.md` | Calibrating what a completed audit looks like |
