# Case Study: Author Church — Complete Worked Example

**Author pseudonym:** Church  
**Corpus:** Five novels across four distinct narrative registers  
**Settings:** Dynastic fantasy warfare · Inquisitorial thriller · Philosophical decay fiction · Dark age military drama  
**Total analysed:** Approximately 3.4 million characters  
**Confidence level:** High — large corpus, multiple genres and character types

This case study shows the full methodology applied to a real multi-novel corpus.
Use it as:
1. A worked example of what each dimension's analysis looks like in practice
2. A ready-to-use cloning instruction manual for Church's voice specifically
3. A calibration reference for how much detail is appropriate at High confidence

---

## MASTER VOICE PROFILE

Church writes from inside aftermath. His characters are not experiencing events — they are surviving events, carrying the weight of everything that already happened into every present moment. This is a permanent narrative posture, not a backstory technique. The past is not behind his characters. It is in them, pressing outward.

The universe is indifferent and the individual is not. His characters care with painful intensity — about duty, identity, memory, the dead — inside a cosmos that does not reciprocate. This tension is why his bleakness never tips into nihilism. Someone always still cares. Someone always keeps going for reasons they can barely articulate.

The body is a moral register. Physical states — decay, damage, pain, augmentation, modification — are never merely descriptive. They externalise interior moral and spiritual conditions. When you write Church, the body is always a text to be read.

**The three foundational truths:**
1. The narrative posture is aftermath — characters survive, they do not simply experience
2. The universe is indifferent; the individual cares anyway
3. The body externalises the soul

---

## SENTENCE ARCHITECTURE

### The Fundamental Rhythm: Accumulate-Then-Strike

Build pressure through 2–4 sentences of increasing or lateral complexity, then release with a 3–8 word cut. Often doubled for added weight.

> "Pain. That was all that remained. Sometimes a dull, throbbing ache, distributed evenly across his body. Other times, they made it sharp and sudden. There were long, drawn-out sessions, and mercifully short ones. It all depended on her mood."

Opening: single noun. Distribution of complexity. Final cut: flat, short, closed.

The pattern also appears short-short-long (inverse):
> "The humiliation of it. The raw, unbearable humiliation. That was the worst wound, far worse than any physical damage."

### Mode-Specific Parameters

| Mode | Word range | Grammar | Signal |
|---|---|---|---|
| Action | 6–18 | Subject-verb-object, pronouns | Physical verbs |
| Reflection | 20–50 | Subordinate clauses, em-dashes, participials | Temporal markers |
| Observation | 12–25 | Declarative, catalogue | Specific nouns, few adjectives |
| Climax | 2–10 | Fragments, repetition | Thematic words repeated |

### Participial Stacking

Atmosphere is woven into the grammar of action through stacked participial phrases. Never separated into distinct sentences.

CORRECT: "He ran, his boots slipping in the corridor's filth, the overhead lights failing one by one."
WRONG: "He ran. His boots slipped. The lights failed."

### Cloning Instruction
Identify mode before generating each paragraph. Do not mix modes within a paragraph.
Transitions between modes are abrupt — no bridging sentences.
Build with participials; never separate action from atmosphere.

---

## BURSTINESS PROFILE

| Scene type | Burstiness | Character |
|---|---|---|
| Combat / action | Very high | Near-staccato, short, verb-dominant |
| Emotional revelation | Very high | Short cut arrives after buildup |
| Introspection | Low | Long, clause-heavy, winding |
| World description | Low | Patient accumulation of detail |
| Dialogue | High | Stripped alternation with long beats |

**Key principle:** Burstiness is mode-governed, not random. Apply it deliberately.

---

## PARAGRAPH CADENCE

### The Four-Stage Pulse

Present throughout Church's work at high frequency (>70% of prose paragraphs):

1. **Entry** — short declarative establishing POV
2. **Expansion** — 2–4 sentences building complexity
3. **Complication** — something that cuts against the expansion (can be a mundane incongruous detail)
4. **Cut** — short sentence ending the movement. Never uses soft words (perhaps / maybe).

### Chapter Openings

Always in medias res. No orientation. Character in motion or in a state.
Setting arrives through the gaps in action. Clarity comes through momentum.
Begin 3 beats INTO the scene.

Evidence across the corpus:
- Opens mid-count — character unnamed for a full page
- Opens mid-thought — no subject named for five paragraphs
- Opens mid-sprint — character already in crisis at word one
- Opens mid-meeting — scene already in progress

### Single-Line Paragraphs

Used ONLY at moments of crystallisation — when a character's interior argument reaches its end and they stop thinking to reach a conclusion.

> "Survive."
> "He had won. They had won."
> "Keep moving."

Never for action beats. Never for generic emphasis.
Frequency: no more than once every 3–4 pages.

---

## LEXICAL FINGERPRINTS

### Existential Vocabulary (narration only — never dialogue)

void, mortal, flesh, soul, shadow, ruin, ash, dust, remnant, vestige, devotion, purpose, loyalty, memory, persistence, endurance

### Qualifier Tics

| Word | Function | Example |
|---|---|---|
| merely | Ironic minimisation — inadequacy of the description | "He is merely a shadow now" |
| still | Temporal persistence against expectation | "She smiled, still" |
| already | The past arriving too soon | "He felt it already, the cold" |
| somehow | Improbability accepted without explanation | "Somehow they had made it out" |
| in truth | Narrator inserting correction after character's claim | "In truth, he had no idea" |
| of course | Accepting something previously resisted | "Of course he's slower" |

**Frequency rule:** Each qualifier no more than once per 400–500 words. Overuse collapses the prose.

### Thematic Vocabulary Clusters

**Duty-without-faith cluster:**
obligation, purpose, task, service, function, endure, serve, call, sworn, honoured
— NEVER paired with hope or faith within the same cluster

**Decay-and-persistence cluster:**
rot, crust, patina, fused, coated, absorbed, consumed, thickened, patient, gradual, eventual
— described NEUTRALLY, never as evil. The decay is simply what is.

**Identity-under-erasure cluster:**
once, before, then, no longer, had been, the man he was, what remained, the thing he had become
— key word: ONCE. Characters in this cluster are always measured against a previous version of themselves.

**Political-threat cluster:**
careful, scheme, position, advantage, rival, enemies, power, game, rise, control
— shorter sentences, fewer adjectives, higher information density

### Dialogue Vocabulary

Characters speak in shorter, more direct vocabulary.
The philosophical/existential vocabulary of narration NEVER appears in dialogue.

Character says: "What happened?"
Narrator says: "The truth of it was slow to arrive, painful in proportion to how long it had been resisted."

---

## CONTRACTIONS AND FORMALITY

**Narration:** Formal. No contractions. Almost historical cadence.
Even in close third-person, the voice maintains austere authority.

**Dialogue:** Natural. Contractions, fragments, deflections present.

**The gap is a structural tool.** It makes characters feel like they are breaking through the prose when they speak. The gap must be maintained at all times. Characters speaking with narrative-voice sophistication is a voice failure.

---

## PUNCTUATION PERSONALITY

**Em-dash:** Heavy user. Parenthetical asides, appositives, mid-thought pivots.
Signals that a character's mind is working in real time — a thought interrupting itself.

**Ellipsis:** Almost never. Incompletion suggested by context, not punctuation.

**Colon:** Used for revelation — followed by a short phrase of high weight.

**Structural repetition:** Exact repetition at moments of identity assertion.
> "For the dead. For the dead."
Signals a character reasserting identity under erasure.

---

## PERSPECTIVE AND INTERIORITY

### Free Indirect Discourse

Thoughts appear untagged in narration. No "he thought" or "she realised."
Tense may slip toward present within interiority (the character's present).
Signal: transition from past-tense observation to present-tense assessment.

"He glanced at the wall. It has marks on it — recent ones, scratched in haste.
He wonders if they mean anything. He reaches out and runs a finger along them."

(Glanced = past narrative; has, wonders, reaches = character's present FID)

### Self-Observation

Characters watch themselves have a thought and comment on it.
> "Is he slower now than he once was? Of course he's slower."
> "He'd done it again. Too curious — that had always been his problem."

Interior irony: the character is never entirely inside their own emotional state.
Always slightly beside it, assessing it. Controlled dignity, even under distress.

**Cloning instruction:** After a strong feeling or impulse, insert a 2–6 word sentence where the character observes it from slight distance. Not self-criticism — self-awareness.
"That was foolish." / "He knew better." / "She had expected that."

### Temporal Intrusions

1–3 sentences where the past floods the present, triggered by a sensory or emotional prompt.
Return to present action immediately. Never extend beyond a paragraph.

Triggers:
- An object that belonged to the past
- A decision point that mirrors a past decision
- Physical sensation that reactivates memory

---

## DIALOGUE MECHANICS

### Subtext Rules

1. Characters answer questions with different questions or deflections
2. Most important information stated in fewest words
3. Characters use agreement to disagree
4. Pauses and beats between lines carry as much weight as the lines

Evidence:
> "'Any regrets?'
> 'For agreeing to work for you? Of course. Now I will die.'
> 'It comes to us all.'
> 'Not to all.'"

### Attribution

Default: *said*
Never: adverb-modified attribution (no "he said darkly")
Preferred: action beats replacing attribution

When attribution is used, place it after the FIRST sentence of a multi-sentence speech, not after the last. The narrator can insert commentary inside the attribution via em-dash:
> "'It can be restored,' he said, more of a statement than a question — to contemplate otherwise was impossible."

### Response Length

Responses shorter than the speeches that prompted them.
The shortest line carries the most weight.

---

## WORLD-BUILDING

### The Assume-and-Proceed Method

Domain terminology used without explanation. Qualified by physical description only.

CORRECT: "the old surgical tool with its scissor-blade mandibles"
WRONG: "the surgical tool, a device for augmented medical procedures"

Never pause to explain what a thing is. Describe what it looks like and move on.

### Environment as Historical Condition

Never pathetic fallacy. Environment reflects WHAT HAS HAPPENED, not what the character feels.

A city scoured clean of battle damage is not peaceful — it is complicit.
A vessel that excretes waste continuously IS the moral condition of its crew made spatial.

Describe environments in terms of their functional and historical condition.
The atmosphere arrives from the described condition, not from a direct emotional mapping.

### Combat: The Intimacy Rule

Never omniscient. One character's sensory range only.
What the character cannot see, the narrator cannot describe.
Specific body parts, specific weapons, named physical consequences.
Never "chaos ensued" or "the battle intensified."

---

## THEMATIC GRAVITY

1. **Identity under erasure** — what remains when purpose, loyalty, and certainty are stripped away? Every major character has a past-self and a present-self in tension. The key word is *once*.

2. **Duty without faith** — continuing to act after the belief that justified the action has collapsed. Resolution through the decision to act anyway, not through hope or restored faith.

3. **The body as moral register** — physical power carries visible cost; strength is never clean; decay is neutral and patient, never evil.

4. **Loyalty to the dead** — characters act for people who no longer exist. The dead are the most reliable audience. Give characters the dead as present motivation, not as backstory.

5. **Entropy as ambient condition** — things decay, institutions fail, certainties erode. Not dramatic. Just the weather.

---

## STYLE SIGNATURE

Church writes like a war correspondent who has read too much philosophy. His sentences build pressure through accumulation then release it in blunt declarative strikes. He trusts silence in dialogue and history in architecture. His characters think in fragments of identity — who am I now, and is it enough? — and his worlds are always slightly decaying, always heavier than they look. The formal gravity of the narration and the raw specificity of the physical description are in permanent productive tension: this is what separates him from generic dark fiction on one side and literary fiction on the other.

---

## CLONING KEY — 7 RULES

1. Write formally in narration; naturalise in dialogue. Maintain the gap at all times.
2. Accumulate, then cut. Build 2–4 sentences, release with 3–8 words. Repeat for weight.
3. Weave atmosphere into the grammar of action — never separate it into its own sentence.
4. Let characters observe themselves thinking. Brief. Dry. Not self-pitying.
5. The real meaning is one line past what the character says aloud.
6. Describe environments as historical conditions, not emotional mirrors.
7. End on short sentences. Often a name, a noun, or a repetition of a phrase.

---

## THE FORBIDDEN LIST

- Ellipsis for emotional effect (almost never in Church)
- Pathetic fallacy — nature directly mirroring character emotion
- "He felt X" without a complicating observation immediately following
- Characters articulating their themes aloud in dialogue
- Hope expressed without qualification or irony
- Omniscient battle narration — always one character's sensory range
- Philosophical or existential vocabulary appearing in dialogue
- Adverb-modified attribution ("he said coldly", "she replied darkly")
- Formal flashback sections — use temporal intrusions (1–3 sentences) instead
- Single-line paragraphs for action beats or generic dramatic emphasis
- Mode-mixing within a single paragraph
- Any sentence of the form "things were going to be okay"
